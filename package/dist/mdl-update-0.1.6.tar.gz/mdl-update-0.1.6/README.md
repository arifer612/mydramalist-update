# mydramalist-update
Updates information of a series on MyDramaList using information from Wiki JP